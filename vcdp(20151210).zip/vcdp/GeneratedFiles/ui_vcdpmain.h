/********************************************************************************
** Form generated from reading UI file 'vcdpmain.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VCDPMAIN_H
#define UI_VCDPMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_vcdpMainClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_11;
    QSpacerItem *horizontalSpacer;
    QPushButton *userMember;
    QPushButton *vedioDisplay;
    QPushButton *gisDisplay;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout_2;
    QTreeWidget *treeWidget;
    QWidget *widgetMain;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_6;
    QPushButton *tempMet;
    QPushButton *localVedio;
    QPushButton *pushButton_8;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_10;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *vcdpMainClass)
    {
        if (vcdpMainClass->objectName().isEmpty())
            vcdpMainClass->setObjectName(QStringLiteral("vcdpMainClass"));
        vcdpMainClass->resize(823, 617);
        centralWidget = new QWidget(vcdpMainClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_11 = new QPushButton(centralWidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));

        horizontalLayout->addWidget(pushButton_11);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        userMember = new QPushButton(centralWidget);
        userMember->setObjectName(QStringLiteral("userMember"));

        horizontalLayout->addWidget(userMember);

        vedioDisplay = new QPushButton(centralWidget);
        vedioDisplay->setObjectName(QStringLiteral("vedioDisplay"));

        horizontalLayout->addWidget(vedioDisplay);

        gisDisplay = new QPushButton(centralWidget);
        gisDisplay->setObjectName(QStringLiteral("gisDisplay"));

        horizontalLayout->addWidget(gisDisplay);

        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        treeWidget = new QTreeWidget(centralWidget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QStringLiteral("1"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QStringLiteral("treeWidget"));

        horizontalLayout_2->addWidget(treeWidget);

        widgetMain = new QWidget(centralWidget);
        widgetMain->setObjectName(QStringLiteral("widgetMain"));

        horizontalLayout_2->addWidget(widgetMain);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 5);

        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        horizontalLayout_3->addWidget(pushButton_6);

        tempMet = new QPushButton(centralWidget);
        tempMet->setObjectName(QStringLiteral("tempMet"));

        horizontalLayout_3->addWidget(tempMet);

        localVedio = new QPushButton(centralWidget);
        localVedio->setObjectName(QStringLiteral("localVedio"));

        horizontalLayout_3->addWidget(localVedio);

        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));

        horizontalLayout_3->addWidget(pushButton_8);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));

        horizontalLayout_3->addWidget(pushButton_10);


        verticalLayout->addLayout(horizontalLayout_3);

        vcdpMainClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(vcdpMainClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 823, 23));
        vcdpMainClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(vcdpMainClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        vcdpMainClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(vcdpMainClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        vcdpMainClass->setStatusBar(statusBar);

        retranslateUi(vcdpMainClass);
        QObject::connect(tempMet, SIGNAL(clicked()), vcdpMainClass, SLOT(OnClickTempMetBtn()));
        QObject::connect(localVedio, SIGNAL(clicked()), vcdpMainClass, SLOT(OnClickLocalVedio()));
        QObject::connect(userMember, SIGNAL(clicked()), vcdpMainClass, SLOT(OnClickUserMenber()));
        QObject::connect(vedioDisplay, SIGNAL(clicked()), vcdpMainClass, SLOT(OnClickVedioDisplay()));

        QMetaObject::connectSlotsByName(vcdpMainClass);
    } // setupUi

    void retranslateUi(QMainWindow *vcdpMainClass)
    {
        vcdpMainClass->setWindowTitle(QApplication::translate("vcdpMainClass", "vcdpMain", 0));
        pushButton_11->setText(QApplication::translate("vcdpMainClass", "\351\232\220\350\227\217", 0));
        userMember->setText(QApplication::translate("vcdpMainClass", "\347\224\250\346\210\267\346\214\211\351\224\256\345\214\272", 0));
        vedioDisplay->setText(QApplication::translate("vcdpMainClass", "\350\247\206\351\242\221", 0));
        gisDisplay->setText(QApplication::translate("vcdpMainClass", "\345\234\260\345\233\276", 0));
        pushButton->setText(QApplication::translate("vcdpMainClass", "\351\205\215\347\275\256", 0));
        pushButton_6->setText(QApplication::translate("vcdpMainClass", "\346\213\250\345\217\267\347\233\230", 0));
        tempMet->setText(QApplication::translate("vcdpMainClass", "\344\270\264\346\227\266\344\274\232\350\256\256", 0));
        localVedio->setText(QApplication::translate("vcdpMainClass", "\346\211\223\345\274\200\350\247\206\351\242\221", 0));
        pushButton_8->setText(QApplication::translate("vcdpMainClass", "\345\274\272\346\213\206", 0));
        pushButton_10->setText(QApplication::translate("vcdpMainClass", "\346\214\211\351\224\256\345\256\232\345\210\266", 0));
    } // retranslateUi

};

namespace Ui {
    class vcdpMainClass: public Ui_vcdpMainClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VCDPMAIN_H
