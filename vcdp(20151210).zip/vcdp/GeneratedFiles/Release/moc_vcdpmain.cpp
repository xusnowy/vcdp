/****************************************************************************
** Meta object code from reading C++ file 'vcdpmain.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../vcdpmain.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'vcdpmain.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_vcdpMain_t {
    QByteArrayData data[6];
    char stringdata0[84];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_vcdpMain_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_vcdpMain_t qt_meta_stringdata_vcdpMain = {
    {
QT_MOC_LITERAL(0, 0, 8), // "vcdpMain"
QT_MOC_LITERAL(1, 9, 17), // "OnClickTempMetBtn"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 17), // "OnClickLocalVedio"
QT_MOC_LITERAL(4, 46, 17), // "OnClickUserMenber"
QT_MOC_LITERAL(5, 64, 19) // "OnClickVedioDisplay"

    },
    "vcdpMain\0OnClickTempMetBtn\0\0"
    "OnClickLocalVedio\0OnClickUserMenber\0"
    "OnClickVedioDisplay"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_vcdpMain[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   34,    2, 0x08 /* Private */,
       3,    0,   35,    2, 0x08 /* Private */,
       4,    0,   36,    2, 0x08 /* Private */,
       5,    0,   37,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void vcdpMain::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        vcdpMain *_t = static_cast<vcdpMain *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->OnClickTempMetBtn(); break;
        case 1: _t->OnClickLocalVedio(); break;
        case 2: _t->OnClickUserMenber(); break;
        case 3: _t->OnClickVedioDisplay(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject vcdpMain::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_vcdpMain.data,
      qt_meta_data_vcdpMain,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *vcdpMain::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *vcdpMain::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_vcdpMain.stringdata0))
        return static_cast<void*>(const_cast< vcdpMain*>(this));
    if (!strcmp(_clname, "KSYSSessionEvent"))
        return static_cast< KSYSSessionEvent*>(const_cast< vcdpMain*>(this));
    if (!strcmp(_clname, "KIMSSessionEvent"))
        return static_cast< KIMSSessionEvent*>(const_cast< vcdpMain*>(this));
    if (!strcmp(_clname, "IIDXCoreNotify"))
        return static_cast< IIDXCoreNotify*>(const_cast< vcdpMain*>(this));
    if (!strcmp(_clname, "IMainCtrl"))
        return static_cast< IMainCtrl*>(const_cast< vcdpMain*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int vcdpMain::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
